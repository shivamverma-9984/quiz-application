var questions =[
    {
        num : 1,
        question : "What does HTML stand for?",
        answer : "Hyper Text Markup Language",
        options : [
            "Hyper Text Multiple Language",
            "Hyper Text Preprocessor",
            "Hyper Tool Multi Language",
            "Hyper Text Markup Language"
        ]
    },
    
 

        {
            num: 2,
            question: "What does CSS stand for?",
            answer: "Cascading Style Sheet",
            options: [
            "Computer Style Sheet",
            "Cascading Style Sheet",
            "Colorful Style Sheet",
            "Common Style Sheet"
            ]
            },
        
    {
num: 3,
question: "What attribute can be added to many HTML/XHTML elements to identify them as a member of a specific group?",
answer: "Class",
options: [
"Id",
"Class",
"Div",
"Span"
]
},
  
{
    num: 4,
    question: "JavaScript is the programming language of the _____.",
    answer: "Web",
    options: [
    "Desktop",
    "Mobile",
    "Web",
    "Server"
    ]
    },

    
{
    num: 5,
    question: " Which type of JavaScript language is _____?",
    answer: "Object-based",
    options: [
    "Object-oriented",
    "Object-based",
    "Functional programming",
    "All of the above"
    ]
    },


{
num: 6,
question: "What does XML stand for?",
answer: "eXtensible Markup Language",
options: [
"eXTra Multi-Program Language",
"eXecutable Multiple Language",
"eXtensible Markup Language",
"eXamine Multiple Language"
]
},
{
num: 7,
question: "What does SQL stand for?",
answer: "Structured Query Language",
options: [
"Statement Question Language",
"Stylesheet Query Language",
"Stylish Question Language",
"Structured Query Language"
]
},

{
num: 8,
question: "What is the full form of DBMS?",
answer: "Database Management System",
options: [
"Data of Binary Management System",
"Database Management System",
"Database Management Service",
"Data Backup Management System"
]
},

{
num: 9,
question: "What does an RDBMS consist of?",
answer: "Collection of Tables",
options: [
"Collection of Records",
" Collection of Keys",
"Collection of Tables",
"Collection of Field"
]
},

{
num: 10,
question: "Which command is used to remove a relation from an SQL?",
answer: "Drop table",
options: [
"Drop table",
"Delete",
"Purge",
"Remove"
]
},


];